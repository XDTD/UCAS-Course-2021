import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;

public class main1 {

    static int count = 0;

    public static void main(String[] args) throws InterruptedException {
        int N = 20; // 线程数从1到N
        long[] BackoffLockTimeCosts = new long[N];
        long[] TASLockTimeCosts = new long[N];
        long[] TTASLockTimeCosts = new long[N];

        for(int i = 1; i < N; i++) {
            count = 0;
            Lock lock = new BackoffLock();
            long timeCost = test(lock, N);
            BackoffLockTimeCosts[i] = timeCost;
//            writeTxt(timeCost, "BackoffLock.txt");
            count = 0;

            lock = new TASLock();
            timeCost = test(lock, N);
            TASLockTimeCosts[i] = timeCost;
//            writeTxt(timeCost, "TASLock.txt");
            count = 0;

            lock = new TTASLock();
            timeCost = test(lock, N);
//            writeTxt(timeCost, "TTASLock.txt");
            TTASLockTimeCosts[i] = timeCost;
        }

        for(int i = 1; i < N; i++) {
            writeTxt(TTASLockTimeCosts[i],"TTASLockTimeCosts.txt");
            writeTxt(TASLockTimeCosts[i],"TASLockTimeCosts.txt");
            writeTxt(BackoffLockTimeCosts[i],"BackoffLockTimeCosts.txt");
        }


        System.out.println(count);
    }

    private static long test(Lock lock, int N) {
        int countTimes = 1000000;
        long timeCost = 0;
        int M = 50;
        for(int j = 0; j < M; j++) {

            ExecutorService executorService = Executors.newFixedThreadPool(N);
            long start = System.currentTimeMillis();
            for (int i = 0; i < countTimes; i++) {
                executorService.execute(() -> {
                    lock.lock();
                    count++;
                    lock.unlock();
                });
            }


            executorService.shutdown();
            while(true){
                if(executorService.isTerminated()){
                    //System.out.println("Finally do something ");
                    long end = System.currentTimeMillis();
                    timeCost += (end - start) ;
                    break;
                }

            }
        }

        return timeCost/M;
    }

    private static long getTimeCost(Lock lock, int N) {
        int countTimes = 1000000;
        long timeCost = 0;
        int M = 50;
        for(int j = 0; j < M; j++) {

            ExecutorService executorService = Executors.newFixedThreadPool(N);
            long start = System.currentTimeMillis();


            for(int i = 0; i < N; i++) {
                int times = countTimes / N;
                if (i == N - 1) {
                    times += countTimes % N;
                }
                int finalTimes = times;
                new Thread(() -> runMethod(lock, finalTimes), "thread").start();
            }



            executorService.shutdown();
            while(true){
                if(executorService.isTerminated()){
                    long end = System.currentTimeMillis();
                    timeCost += (end - start) ;
                    break;
                }

            }
        }

        return timeCost/M;
    }


    private static void runMethod(Lock lock, int N) {
        for(int i = 0; i < N; i++) {
            lock.lock();
            count++;
            lock.unlock();
        }
    }

    private static void writeTxt(long writeData, String filename) {
        FileWriter fw = null;
        try {
            //如果文件存在，则追加内容；如果文件不存在，则创建文件
            File f=new File(filename);
            if(!f.exists()) {
                f.createNewFile();
            }
            fw = new FileWriter(f, true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        PrintWriter pw = new PrintWriter(fw);
        pw.println(writeData);
        pw.flush();
        try {
            fw.flush();
            pw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



