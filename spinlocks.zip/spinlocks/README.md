In this repository, implementing 4 different spin lock classes
·         Test-and-Set Lock
·         Test-and-Test-and-Set Lock
·         Backoff lock
·         Anderson Queue Lock
